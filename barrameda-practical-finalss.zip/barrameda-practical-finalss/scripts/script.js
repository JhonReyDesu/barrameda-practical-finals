function handleLogin(event){
 event.preventDefault();

 const email = document.getElementById('email').value.trim();
 const password = document.getElementById('password').value;

 const emailError = document.getElementById('emailError');
 const passwordError = document.getElementById('passwordError');
 
 const success = document.getElementById('success');

 let isValid = true;

 if (email === ''){
  emailError.textContent = 'Email is required.'
  emailError.style.display = 'block';
  isValid = false;
 }

 if (password === ''){
  passwordError.textContent = 'Password is required.'
  passwordError.style.display = 'block';
  isValid = false;
 }
 else if (password < 8){
  passwordError.textContent = 'Password must contain at least 8 characters.'
  passwordError.style.display = 'block';
  isValid = false;
 }

 if(isValid){
  success.textContent = 'Log in successful. Redirecting...'
  success.style.display = 'block';
  event.reset()
 }
}